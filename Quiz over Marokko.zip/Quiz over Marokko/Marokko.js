let currentQuestion = 1;
const totalQuestions = 60; // Adjust the total number of questions accordingly

function updateProgressBar() {
    const progressBar = document.getElementById('progress-bar');
    const progressPercent = document.getElementById('progress-percent');
    const percentage = (currentQuestion / totalQuestions) * 100;

    progressBar.style.width = `${percentage}%`;
    progressPercent.innerText = `${Math.round(percentage)}%`;
}

function checkAnswer(questionNumber, correctAnswer) {
    const selectedAnswer = document.querySelector(`input[name="q${questionNumber}"]:checked`);
    const questionDiv = document.getElementById(`question${questionNumber}`);
    const feedbackDiv = document.getElementById(`feedback${questionNumber}`);

    if (selectedAnswer) {
        if (selectedAnswer.value === correctAnswer) {
            questionDiv.style.backgroundColor = '#9FFF8F'; // Green background for correct answer
            feedbackDiv.innerText = 'Correct!';
        } else {
            questionDiv.style.backgroundColor = '#FF8F8F'; // Red background for incorrect answer
            feedbackDiv.innerText = 'Incorrect!';
        }

        setTimeout(() => {
            questionDiv.style.display = 'none';
            const nextQuestionElement = document.getElementById(`question${currentQuestion + 1}`);

            if (nextQuestionElement) {
                nextQuestionElement.style.display = 'block';
                currentQuestion++;
                updateProgressBar();
            } else {
                document.getElementById('finish-button').style.display = 'block';
            }
        }, 2000); // Display feedback for 2 seconds before moving to the next question
    } else {
        alert('Please select an answer before moving on.');
    }
}

function nextQuestion(questionNumber) {
    document.getElementById(`feedback${questionNumber}`).innerText = ''; // Clear previous feedback
    checkAnswer(questionNumber, 'A'); // Replace 'A' with the correct answer for the current question
}


function finishQuiz() {
    alert('Quiz finished!'); // You can customize this message or perform additional actions here
}
